# Travello Backend API

A RESTful backend API for a **Travello travel-booking application**, built with **Node.js, Express.js, MongoDB, and JWT authentication**.

The API provides user authentication, OTP verification, destinations, tours, and bookings. Swagger UI is included for interactive API documentation.

## Features

- User registration and login
- Password hashing with bcrypt
- OTP-based account verification
- JWT authentication
- Protected routes
- Role-based authorization (`user` / `admin`)
- Destination CRUD
- Tour CRUD
- Tour filtering by destination
- Booking creation with seat availability checking
- Booking cancellation
- Admin booking management
- Global error handling
- CORS support
- Swagger/OpenAPI documentation

## Technologies

- Node.js
- Express.js
- MongoDB
- Mongoose
- JSON Web Token (JWT)
- bcryptjs
- dotenv
- Swagger / OpenAPI
- Nodemon

## Project Structure

```text
class26/
├── app.js
├── server.js
├── package.json
├── package-lock.json
│
├── config/
│   ├── db.js
│   └── swagger.js
│
├── controllers/
│   ├── auth.controller.js
│   ├── booking.controller.js
│   ├── destination.controller.js
│   └── tour.controller.js
│
├── middlewares/
│   ├── auth.middleware.js
│   └── error.middleware.js
│
├── models/
│   ├── Booking.js
│   ├── Destination.js
│   ├── Tour.js
│   └── User.js
│
├── routes/
│   ├── auth.routes.js
│   ├── booking.routes.js
│   ├── destination.routes.js
│   └── tour.routes.js
│
└── utils/
    ├── AppError.js
    ├── catchAsync.js
    ├── generateOtp.js
    ├── signToken.js
    └── slugify.js
```

## Requirements

Install the following before running the project:

- Node.js 18+ recommended
- MongoDB database
- npm

Check your versions:

```bash
node -v
npm -v
```

## Installation

Clone or extract the project and open the project folder:

```bash
cd class26
```

Install dependencies:

```bash
npm install
```

## Environment Variables

Create a `.env` file in the project root:

```env
PORT=5000

MONGO_URI=mongodb://127.0.0.1:27017/travello

JWT_SECRET=your_super_secret_jwt_key
JWT_EXPIRES_IN=7d

OTP_EXPIRES_MIN=10
```

### MongoDB Atlas

If you are using MongoDB Atlas, replace `MONGO_URI` with your Atlas connection string:

```env
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@CLUSTER.mongodb.net/travello
```

Do not commit `.env` to GitHub.

## Run the Project

### Development

```bash
npm run dev
```

This starts the server using Nodemon.

### Production

```bash
npm start
```

If everything is configured correctly, you should see:

```text
MongoDB connected
Server running on port 5000
```

## API Base URL

```text
http://localhost:5000/api
```

## Swagger API Documentation

After starting the server, open:

```text
http://localhost:5000/api/docs
```

Swagger provides an interactive interface where you can view and test the API endpoints.

## Authentication Flow

### 1. Register

```http
POST /api/auth/register
```

Example request:

```json
{
  "name": "Test User",
  "email": "test@example.com",
  "password": "password123"
}
```

The development response includes `devOtp`, and the OTP is also printed in the server console.

### 2. Verify OTP

```http
POST /api/auth/verify-otp
```

Example:

```json
{
  "email": "test@example.com",
  "otp": "123456"
}
```

A successful verification returns a JWT token.

### 3. Login

```http
POST /api/auth/login
```

Example:

```json
{
  "email": "test@example.com",
  "password": "password123"
}
```

Response includes a JWT token.

### 4. Send JWT

For protected endpoints, send the token in the Authorization header:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

## API Endpoints

### Authentication

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register a user |
| POST | `/api/auth/verify-otp` | Public | Verify account OTP |
| POST | `/api/auth/resend-otp` | Public | Resend OTP |
| POST | `/api/auth/login` | Public | Login |
| GET | `/api/auth/me` | Authenticated | Get current user |

### Destinations

| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/api/destinations` | Public | Get all destinations |
| GET | `/api/destinations/:id` | Public | Get one destination |
| POST | `/api/destinations` | Admin | Create destination |
| PATCH | `/api/destinations/:id` | Admin | Update destination |
| DELETE | `/api/destinations/:id` | Admin | Delete destination |

### Tours

| Method | Endpoint | Access | Description |
|---|---|---|---|
| GET | `/api/tours` | Public | Get all tours |
| GET | `/api/tours/:id` | Public | Get one tour |
| POST | `/api/tours` | Admin | Create tour |
| PATCH | `/api/tours/:id` | Admin | Update tour |
| DELETE | `/api/tours/:id` | Admin | Delete tour |

Tours can also be filtered by destination:

```http
GET /api/tours?destination=DESTINATION_ID
```

### Bookings

| Method | Endpoint | Access | Description |
|---|---|---|---|
| POST | `/api/bookings` | User/Admin | Create booking |
| GET | `/api/bookings/my` | Authenticated | Get current user's bookings |
| PATCH | `/api/bookings/:id/cancel` | Owner/Admin | Cancel booking |
| GET | `/api/bookings` | Admin | Get all bookings |
| PATCH | `/api/bookings/:id/status` | Admin | Update booking status |

## Example Destination

```json
{
  "name": "Sylhet Hills",
  "description": "Tea gardens and beautiful hills",
  "region": "Sylhet",
  "image": "https://example.com/sylhet.jpg"
}
```

## Example Tour

```json
{
  "title": "3-Day Sylhet Adventure",
  "destination": "DESTINATION_ID",
  "description": "Explore the tea gardens and hills of Sylhet.",
  "price": 175,
  "duration": 3,
  "date": "2026-10-15",
  "seatsAvailable": 10,
  "image": "https://example.com/sylhet-tour.jpg"
}
```

## Example Booking

```json
{
  "tourId": "TOUR_ID",
  "numGuests": 2
}
```

The API calculates the booking's `totalPrice` from the tour price and requested number of guests.

## User Roles

There are two roles:

```text
user
admin
```

Normal users can:

- Register
- Verify their account
- Login
- View destinations
- View tours
- Create bookings
- View their bookings
- Cancel their own bookings

Admins can additionally:

- Create/update/delete destinations
- Create/update/delete tours
- View all bookings
- Update booking status
- Cancel bookings as an administrator

## OTP Note

This project currently uses a development OTP flow.

The OTP is:

- Printed in the server console
- Returned as `devOtp` in the registration/resend response

For production, replace the development OTP logic with a real email service such as SMTP/Nodemailer or another transactional email provider.

## Error Handling

The project uses centralized error handling through:

```text
middlewares/error.middleware.js
```

Unknown routes are also handled automatically and return a `404` error.

## Testing with Postman / Thunder Client

Recommended testing sequence:

1. Start MongoDB.
2. Start the Node.js server.
3. Register a user.
4. Copy the OTP from the response or terminal.
5. Verify the OTP.
6. Login and copy the JWT token.
7. Use:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

8. Test protected endpoints.
9. For admin-only endpoints, use a user whose database `role` is `admin`.

## Production Checklist

Before deploying to production:

- Set a strong `JWT_SECRET`
- Use a production MongoDB database
- Add a real email/OTP provider
- Do not return `devOtp`
- Add rate limiting
- Add request validation
- Configure production CORS
- Use HTTPS
- Keep `.env` out of source control
- Add proper logging/monitoring
- Review MongoDB security and network access rules

## License

This project is provided for educational and development purposes.
