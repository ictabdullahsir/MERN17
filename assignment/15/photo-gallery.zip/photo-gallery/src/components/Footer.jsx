function Footer() {
  return (
    <footer className="footer">
      <p>
        Photo data: JSONPlaceholder API · React + Vite দিয়ে তৈরি ·{" "}
        {new Date().getFullYear()}
      </p>
    </footer>
  );
}

export default Footer;
